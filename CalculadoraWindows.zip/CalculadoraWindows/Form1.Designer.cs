﻿namespace CalculadoraWindows
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnUmporX = new System.Windows.Forms.Button();
            this.BtnXaoQuadrado = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSubtracao = new System.Windows.Forms.Button();
            this.BtnLimparTudo = new System.Windows.Forms.Button();
            this.BtnMultiplicacao = new System.Windows.Forms.Button();
            this.BtnVirgula = new System.Windows.Forms.Button();
            this.BtnZero = new System.Windows.Forms.Button();
            this.BtnPorcetagem = new System.Windows.Forms.Button();
            this.BtnUm = new System.Windows.Forms.Button();
            this.BtnSete = new System.Windows.Forms.Button();
            this.BtnQuatro = new System.Windows.Forms.Button();
            this.BtnRaiz = new System.Windows.Forms.Button();
            this.BtnNove = new System.Windows.Forms.Button();
            this.BtnAdicao = new System.Windows.Forms.Button();
            this.BtnIgual = new System.Windows.Forms.Button();
            this.BtnOito = new System.Windows.Forms.Button();
            this.BtnSeis = new System.Windows.Forms.Button();
            this.BtnTres = new System.Windows.Forms.Button();
            this.BtnCinco = new System.Windows.Forms.Button();
            this.BtnDois = new System.Windows.Forms.Button();
            this.BtnMenosEmais = new System.Windows.Forms.Button();
            this.BtnDivisao = new System.Windows.Forms.Button();
            this.BtnExcloir = new System.Windows.Forms.Button();
            this.LinkLblMC = new System.Windows.Forms.LinkLabel();
            this.linkLblMR = new System.Windows.Forms.LinkLabel();
            this.LinlLblMmais = new System.Windows.Forms.LinkLabel();
            this.LinklLblMmenos = new System.Windows.Forms.LinkLabel();
            this.LinkLblM = new System.Windows.Forms.LinkLabel();
            this.LinkLblMS = new System.Windows.Forms.LinkLabel();
            this.TxtResultado = new System.Windows.Forms.TextBox();
            this.LblHistorico = new System.Windows.Forms.Label();
            this.TxtNumeros = new System.Windows.Forms.TextBox();
            this.Historico = new System.Windows.Forms.LinkLabel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // BtnUmporX
            // 
            this.BtnUmporX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUmporX.Location = new System.Drawing.Point(17, 195);
            this.BtnUmporX.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnUmporX.Name = "BtnUmporX";
            this.BtnUmporX.Size = new System.Drawing.Size(76, 57);
            this.BtnUmporX.TabIndex = 0;
            this.BtnUmporX.Text = "1 / X";
            this.BtnUmporX.UseVisualStyleBackColor = true;
            this.BtnUmporX.Click += new System.EventHandler(this.BtnUmporX_Click);
            // 
            // BtnXaoQuadrado
            // 
            this.BtnXaoQuadrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnXaoQuadrado.Location = new System.Drawing.Point(101, 195);
            this.BtnXaoQuadrado.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnXaoQuadrado.Name = "BtnXaoQuadrado";
            this.BtnXaoQuadrado.Size = new System.Drawing.Size(76, 57);
            this.BtnXaoQuadrado.TabIndex = 1;
            this.BtnXaoQuadrado.Text = " x²";
            this.BtnXaoQuadrado.UseVisualStyleBackColor = true;
            this.BtnXaoQuadrado.Click += new System.EventHandler(this.BtnXaoQuadrado_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLimpar.Location = new System.Drawing.Point(185, 131);
            this.BtnLimpar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(76, 57);
            this.BtnLimpar.TabIndex = 2;
            this.BtnLimpar.Text = "C";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSubtracao
            // 
            this.BtnSubtracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSubtracao.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnSubtracao.Location = new System.Drawing.Point(269, 323);
            this.BtnSubtracao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnSubtracao.Name = "BtnSubtracao";
            this.BtnSubtracao.Size = new System.Drawing.Size(76, 57);
            this.BtnSubtracao.TabIndex = 3;
            this.BtnSubtracao.Text = "-";
            this.BtnSubtracao.UseVisualStyleBackColor = true;
            this.BtnSubtracao.Click += new System.EventHandler(this.BtnSubtracao_Click);
            // 
            // BtnLimparTudo
            // 
            this.BtnLimparTudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLimparTudo.Location = new System.Drawing.Point(101, 131);
            this.BtnLimparTudo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnLimparTudo.Name = "BtnLimparTudo";
            this.BtnLimparTudo.Size = new System.Drawing.Size(76, 57);
            this.BtnLimparTudo.TabIndex = 4;
            this.BtnLimparTudo.Text = "CE";
            this.BtnLimparTudo.UseVisualStyleBackColor = true;
            this.BtnLimparTudo.Click += new System.EventHandler(this.BtnLimparTudo_Click);
            // 
            // BtnMultiplicacao
            // 
            this.BtnMultiplicacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMultiplicacao.Location = new System.Drawing.Point(269, 259);
            this.BtnMultiplicacao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnMultiplicacao.Name = "BtnMultiplicacao";
            this.BtnMultiplicacao.Size = new System.Drawing.Size(76, 57);
            this.BtnMultiplicacao.TabIndex = 5;
            this.BtnMultiplicacao.Text = "×";
            this.BtnMultiplicacao.UseVisualStyleBackColor = true;
            this.BtnMultiplicacao.Click += new System.EventHandler(this.BtnMultiplicacao_Click);
            // 
            // BtnVirgula
            // 
            this.BtnVirgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVirgula.Location = new System.Drawing.Point(185, 451);
            this.BtnVirgula.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnVirgula.Name = "BtnVirgula";
            this.BtnVirgula.Size = new System.Drawing.Size(76, 57);
            this.BtnVirgula.TabIndex = 6;
            this.BtnVirgula.Text = ",";
            this.BtnVirgula.UseVisualStyleBackColor = true;
            this.BtnVirgula.Click += new System.EventHandler(this.BtnVirgula_Click);
            // 
            // BtnZero
            // 
            this.BtnZero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnZero.Location = new System.Drawing.Point(101, 451);
            this.BtnZero.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnZero.Name = "BtnZero";
            this.BtnZero.Size = new System.Drawing.Size(76, 57);
            this.BtnZero.TabIndex = 7;
            this.BtnZero.Text = "0";
            this.BtnZero.UseVisualStyleBackColor = true;
            this.BtnZero.Click += new System.EventHandler(this.BtnZero_Click);
            // 
            // BtnPorcetagem
            // 
            this.BtnPorcetagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPorcetagem.Location = new System.Drawing.Point(17, 131);
            this.BtnPorcetagem.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnPorcetagem.Name = "BtnPorcetagem";
            this.BtnPorcetagem.Size = new System.Drawing.Size(76, 57);
            this.BtnPorcetagem.TabIndex = 8;
            this.BtnPorcetagem.Text = "%";
            this.BtnPorcetagem.UseVisualStyleBackColor = true;
            this.BtnPorcetagem.Click += new System.EventHandler(this.BtnPorcetagem_Click);
            // 
            // BtnUm
            // 
            this.BtnUm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUm.Location = new System.Drawing.Point(17, 387);
            this.BtnUm.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnUm.Name = "BtnUm";
            this.BtnUm.Size = new System.Drawing.Size(76, 57);
            this.BtnUm.TabIndex = 9;
            this.BtnUm.Text = "1";
            this.BtnUm.UseVisualStyleBackColor = true;
            this.BtnUm.Click += new System.EventHandler(this.BtnUm_Click);
            // 
            // BtnSete
            // 
            this.BtnSete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSete.Location = new System.Drawing.Point(17, 259);
            this.BtnSete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnSete.Name = "BtnSete";
            this.BtnSete.Size = new System.Drawing.Size(76, 57);
            this.BtnSete.TabIndex = 10;
            this.BtnSete.Text = "7";
            this.BtnSete.UseVisualStyleBackColor = true;
            this.BtnSete.Click += new System.EventHandler(this.BtnSete_Click);
            // 
            // BtnQuatro
            // 
            this.BtnQuatro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnQuatro.Location = new System.Drawing.Point(17, 323);
            this.BtnQuatro.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnQuatro.Name = "BtnQuatro";
            this.BtnQuatro.Size = new System.Drawing.Size(76, 57);
            this.BtnQuatro.TabIndex = 11;
            this.BtnQuatro.Text = "4";
            this.BtnQuatro.UseVisualStyleBackColor = true;
            this.BtnQuatro.Click += new System.EventHandler(this.BtnQuatro_Click);
            // 
            // BtnRaiz
            // 
            this.BtnRaiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRaiz.Location = new System.Drawing.Point(185, 195);
            this.BtnRaiz.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnRaiz.Name = "BtnRaiz";
            this.BtnRaiz.Size = new System.Drawing.Size(76, 57);
            this.BtnRaiz.TabIndex = 12;
            this.BtnRaiz.Text = "√";
            this.BtnRaiz.UseVisualStyleBackColor = true;
            this.BtnRaiz.Click += new System.EventHandler(this.BtnRaiz_Click);
            // 
            // BtnNove
            // 
            this.BtnNove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNove.Location = new System.Drawing.Point(185, 259);
            this.BtnNove.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnNove.Name = "BtnNove";
            this.BtnNove.Size = new System.Drawing.Size(76, 57);
            this.BtnNove.TabIndex = 13;
            this.BtnNove.Text = "9";
            this.BtnNove.UseVisualStyleBackColor = true;
            this.BtnNove.Click += new System.EventHandler(this.BtnNove_Click);
            // 
            // BtnAdicao
            // 
            this.BtnAdicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdicao.Location = new System.Drawing.Point(269, 387);
            this.BtnAdicao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnAdicao.Name = "BtnAdicao";
            this.BtnAdicao.Size = new System.Drawing.Size(76, 57);
            this.BtnAdicao.TabIndex = 14;
            this.BtnAdicao.Text = "+";
            this.BtnAdicao.UseVisualStyleBackColor = true;
            this.BtnAdicao.Click += new System.EventHandler(this.BtnAdicao_Click);
            // 
            // BtnIgual
            // 
            this.BtnIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnIgual.Location = new System.Drawing.Point(269, 451);
            this.BtnIgual.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnIgual.Name = "BtnIgual";
            this.BtnIgual.Size = new System.Drawing.Size(76, 57);
            this.BtnIgual.TabIndex = 15;
            this.BtnIgual.Text = "=";
            this.BtnIgual.UseVisualStyleBackColor = true;
            this.BtnIgual.Click += new System.EventHandler(this.BtnIgual_Click);
            // 
            // BtnOito
            // 
            this.BtnOito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOito.Location = new System.Drawing.Point(101, 259);
            this.BtnOito.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnOito.Name = "BtnOito";
            this.BtnOito.Size = new System.Drawing.Size(76, 57);
            this.BtnOito.TabIndex = 16;
            this.BtnOito.Text = "8";
            this.BtnOito.UseVisualStyleBackColor = true;
            this.BtnOito.Click += new System.EventHandler(this.BtnOito_Click);
            // 
            // BtnSeis
            // 
            this.BtnSeis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSeis.Location = new System.Drawing.Point(185, 323);
            this.BtnSeis.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnSeis.Name = "BtnSeis";
            this.BtnSeis.Size = new System.Drawing.Size(76, 57);
            this.BtnSeis.TabIndex = 17;
            this.BtnSeis.Text = "6";
            this.BtnSeis.UseVisualStyleBackColor = true;
            this.BtnSeis.Click += new System.EventHandler(this.BtnSeis_Click);
            // 
            // BtnTres
            // 
            this.BtnTres.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTres.Location = new System.Drawing.Point(185, 387);
            this.BtnTres.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnTres.Name = "BtnTres";
            this.BtnTres.Size = new System.Drawing.Size(76, 57);
            this.BtnTres.TabIndex = 18;
            this.BtnTres.Text = "3";
            this.BtnTres.UseVisualStyleBackColor = true;
            this.BtnTres.Click += new System.EventHandler(this.BtnTres_Click);
            // 
            // BtnCinco
            // 
            this.BtnCinco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCinco.Location = new System.Drawing.Point(101, 323);
            this.BtnCinco.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnCinco.Name = "BtnCinco";
            this.BtnCinco.Size = new System.Drawing.Size(76, 57);
            this.BtnCinco.TabIndex = 19;
            this.BtnCinco.Text = "5";
            this.BtnCinco.UseVisualStyleBackColor = true;
            this.BtnCinco.Click += new System.EventHandler(this.BtnCinco_Click);
            // 
            // BtnDois
            // 
            this.BtnDois.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDois.Location = new System.Drawing.Point(101, 387);
            this.BtnDois.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnDois.Name = "BtnDois";
            this.BtnDois.Size = new System.Drawing.Size(76, 57);
            this.BtnDois.TabIndex = 20;
            this.BtnDois.Text = "2";
            this.BtnDois.UseVisualStyleBackColor = true;
            this.BtnDois.Click += new System.EventHandler(this.BtnDois_Click);
            // 
            // BtnMenosEmais
            // 
            this.BtnMenosEmais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMenosEmais.Location = new System.Drawing.Point(17, 451);
            this.BtnMenosEmais.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnMenosEmais.Name = "BtnMenosEmais";
            this.BtnMenosEmais.Size = new System.Drawing.Size(76, 57);
            this.BtnMenosEmais.TabIndex = 21;
            this.BtnMenosEmais.Text = "- / +";
            this.BtnMenosEmais.UseVisualStyleBackColor = true;
            this.BtnMenosEmais.Click += new System.EventHandler(this.BtnMenosEmais_Click);
            // 
            // BtnDivisao
            // 
            this.BtnDivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDivisao.Location = new System.Drawing.Point(269, 195);
            this.BtnDivisao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnDivisao.Name = "BtnDivisao";
            this.BtnDivisao.Size = new System.Drawing.Size(76, 57);
            this.BtnDivisao.TabIndex = 22;
            this.BtnDivisao.Text = "÷";
            this.BtnDivisao.UseVisualStyleBackColor = true;
            this.BtnDivisao.Click += new System.EventHandler(this.BtnDivisao_Click);
            // 
            // BtnExcloir
            // 
            this.BtnExcloir.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExcloir.Location = new System.Drawing.Point(269, 131);
            this.BtnExcloir.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnExcloir.Name = "BtnExcloir";
            this.BtnExcloir.Size = new System.Drawing.Size(76, 57);
            this.BtnExcloir.TabIndex = 24;
            this.BtnExcloir.Text = "⌫";
            this.BtnExcloir.UseVisualStyleBackColor = true;
            this.BtnExcloir.Click += new System.EventHandler(this.BtnExcloir_Click);
            // 
            // LinkLblMC
            // 
            this.LinkLblMC.AutoSize = true;
            this.LinkLblMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinkLblMC.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLblMC.LinkColor = System.Drawing.Color.Black;
            this.LinkLblMC.Location = new System.Drawing.Point(25, 102);
            this.LinkLblMC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LinkLblMC.Name = "LinkLblMC";
            this.LinkLblMC.Size = new System.Drawing.Size(33, 20);
            this.LinkLblMC.TabIndex = 25;
            this.LinkLblMC.TabStop = true;
            this.LinkLblMC.Text = "MC";
            this.LinkLblMC.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLblMC_LinkClicked);
            // 
            // linkLblMR
            // 
            this.linkLblMR.AutoSize = true;
            this.linkLblMR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLblMR.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLblMR.LinkColor = System.Drawing.Color.Black;
            this.linkLblMR.Location = new System.Drawing.Point(78, 102);
            this.linkLblMR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLblMR.Name = "linkLblMR";
            this.linkLblMR.Size = new System.Drawing.Size(34, 20);
            this.linkLblMR.TabIndex = 26;
            this.linkLblMR.TabStop = true;
            this.linkLblMR.Text = "MR";
            this.linkLblMR.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLblMR_LinkClicked);
            // 
            // LinlLblMmais
            // 
            this.LinlLblMmais.AutoSize = true;
            this.LinlLblMmais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinlLblMmais.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinlLblMmais.LinkColor = System.Drawing.Color.Black;
            this.LinlLblMmais.Location = new System.Drawing.Point(141, 102);
            this.LinlLblMmais.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LinlLblMmais.Name = "LinlLblMmais";
            this.LinlLblMmais.Size = new System.Drawing.Size(31, 20);
            this.LinlLblMmais.TabIndex = 27;
            this.LinlLblMmais.TabStop = true;
            this.LinlLblMmais.Text = "M+";
            this.LinlLblMmais.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinlLblMmais_LinkClicked);
            // 
            // LinklLblMmenos
            // 
            this.LinklLblMmenos.AutoSize = true;
            this.LinklLblMmenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinklLblMmenos.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinklLblMmenos.LinkColor = System.Drawing.Color.Black;
            this.LinklLblMmenos.Location = new System.Drawing.Point(204, 102);
            this.LinklLblMmenos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LinklLblMmenos.Name = "LinklLblMmenos";
            this.LinklLblMmenos.Size = new System.Drawing.Size(27, 20);
            this.LinklLblMmenos.TabIndex = 28;
            this.LinklLblMmenos.TabStop = true;
            this.LinklLblMmenos.Text = "M-";
            this.LinklLblMmenos.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinklLblMmenos_LinkClicked);
            // 
            // LinkLblM
            // 
            this.LinkLblM.AutoSize = true;
            this.LinkLblM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinkLblM.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLblM.LinkColor = System.Drawing.Color.Black;
            this.LinkLblM.Location = new System.Drawing.Point(313, 102);
            this.LinkLblM.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LinkLblM.Name = "LinkLblM";
            this.LinkLblM.Size = new System.Drawing.Size(22, 20);
            this.LinkLblM.TabIndex = 29;
            this.LinkLblM.TabStop = true;
            this.LinkLblM.Text = "M";
            this.LinkLblM.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLblM_LinkClicked);
            // 
            // LinkLblMS
            // 
            this.LinkLblMS.AutoSize = true;
            this.LinkLblMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinkLblMS.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLblMS.LinkColor = System.Drawing.Color.Black;
            this.LinkLblMS.Location = new System.Drawing.Point(254, 102);
            this.LinkLblMS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LinkLblMS.Name = "LinkLblMS";
            this.LinkLblMS.Size = new System.Drawing.Size(33, 20);
            this.LinkLblMS.TabIndex = 30;
            this.LinkLblMS.TabStop = true;
            this.LinkLblMS.Text = "MS";
            this.LinkLblMS.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLblMS_LinkClicked);
            // 
            // TxtResultado
            // 
            this.TxtResultado.BackColor = System.Drawing.SystemColors.Window;
            this.TxtResultado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtResultado.Font = new System.Drawing.Font("Segoe Fluent Icons", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtResultado.Location = new System.Drawing.Point(18, 46);
            this.TxtResultado.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtResultado.Multiline = true;
            this.TxtResultado.Name = "TxtResultado";
            this.TxtResultado.ReadOnly = true;
            this.TxtResultado.Size = new System.Drawing.Size(327, 33);
            this.TxtResultado.TabIndex = 31;
            this.TxtResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtResultado.TextChanged += new System.EventHandler(this.TxtResultado_TextChanged);
            // 
            // LblHistorico
            // 
            this.LblHistorico.AutoSize = true;
            this.LblHistorico.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblHistorico.Location = new System.Drawing.Point(304, 14);
            this.LblHistorico.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblHistorico.Name = "LblHistorico";
            this.LblHistorico.Size = new System.Drawing.Size(0, 20);
            this.LblHistorico.TabIndex = 33;
            // 
            // TxtNumeros
            // 
            this.TxtNumeros.BackColor = System.Drawing.Color.White;
            this.TxtNumeros.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNumeros.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNumeros.Location = new System.Drawing.Point(50, 9);
            this.TxtNumeros.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtNumeros.Multiline = true;
            this.TxtNumeros.Name = "TxtNumeros";
            this.TxtNumeros.Size = new System.Drawing.Size(299, 35);
            this.TxtNumeros.TabIndex = 34;
            this.TxtNumeros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtNumeros.TextChanged += new System.EventHandler(this.TxtNumeros_TextChanged);
            // 
            // Historico
            // 
            this.Historico.AutoSize = true;
            this.Historico.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Historico.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Historico.LinkColor = System.Drawing.Color.Black;
            this.Historico.Location = new System.Drawing.Point(14, 14);
            this.Historico.Name = "Historico";
            this.Historico.Size = new System.Drawing.Size(32, 24);
            this.Historico.TabIndex = 35;
            this.Historico.TabStop = true;
            this.Historico.Text = "🕘";
            this.Historico.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Historico_LinkClicked);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 24;
            this.listBox1.Location = new System.Drawing.Point(395, 69);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(327, 388);
            this.listBox1.TabIndex = 36;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // listBox2
            // 
            this.listBox2.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 21;
            this.listBox2.Location = new System.Drawing.Point(395, 197);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(328, 256);
            this.listBox2.TabIndex = 37;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(364, 539);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Historico);
            this.Controls.Add(this.TxtNumeros);
            this.Controls.Add(this.LblHistorico);
            this.Controls.Add(this.TxtResultado);
            this.Controls.Add(this.LinkLblMS);
            this.Controls.Add(this.LinkLblM);
            this.Controls.Add(this.LinklLblMmenos);
            this.Controls.Add(this.LinlLblMmais);
            this.Controls.Add(this.linkLblMR);
            this.Controls.Add(this.LinkLblMC);
            this.Controls.Add(this.BtnExcloir);
            this.Controls.Add(this.BtnDivisao);
            this.Controls.Add(this.BtnMenosEmais);
            this.Controls.Add(this.BtnDois);
            this.Controls.Add(this.BtnCinco);
            this.Controls.Add(this.BtnTres);
            this.Controls.Add(this.BtnSeis);
            this.Controls.Add(this.BtnOito);
            this.Controls.Add(this.BtnIgual);
            this.Controls.Add(this.BtnAdicao);
            this.Controls.Add(this.BtnNove);
            this.Controls.Add(this.BtnRaiz);
            this.Controls.Add(this.BtnQuatro);
            this.Controls.Add(this.BtnSete);
            this.Controls.Add(this.BtnUm);
            this.Controls.Add(this.BtnPorcetagem);
            this.Controls.Add(this.BtnZero);
            this.Controls.Add(this.BtnVirgula);
            this.Controls.Add(this.BtnMultiplicacao);
            this.Controls.Add(this.BtnLimparTudo);
            this.Controls.Add(this.BtnSubtracao);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnXaoQuadrado);
            this.Controls.Add(this.BtnUmporX);
            this.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnUmporX;
        private System.Windows.Forms.Button BtnXaoQuadrado;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSubtracao;
        private System.Windows.Forms.Button BtnLimparTudo;
        private System.Windows.Forms.Button BtnMultiplicacao;
        private System.Windows.Forms.Button BtnVirgula;
        private System.Windows.Forms.Button BtnZero;
        private System.Windows.Forms.Button BtnPorcetagem;
        private System.Windows.Forms.Button BtnUm;
        private System.Windows.Forms.Button BtnSete;
        private System.Windows.Forms.Button BtnQuatro;
        private System.Windows.Forms.Button BtnRaiz;
        private System.Windows.Forms.Button BtnNove;
        private System.Windows.Forms.Button BtnAdicao;
        private System.Windows.Forms.Button BtnIgual;
        private System.Windows.Forms.Button BtnOito;
        private System.Windows.Forms.Button BtnSeis;
        private System.Windows.Forms.Button BtnTres;
        private System.Windows.Forms.Button BtnCinco;
        private System.Windows.Forms.Button BtnDois;
        private System.Windows.Forms.Button BtnMenosEmais;
        private System.Windows.Forms.Button BtnDivisao;
        private System.Windows.Forms.Button BtnExcloir;
        private System.Windows.Forms.LinkLabel LinkLblMC;
        private System.Windows.Forms.LinkLabel linkLblMR;
        private System.Windows.Forms.LinkLabel LinlLblMmais;
        private System.Windows.Forms.LinkLabel LinklLblMmenos;
        private System.Windows.Forms.LinkLabel LinkLblM;
        private System.Windows.Forms.LinkLabel LinkLblMS;
        private System.Windows.Forms.TextBox TxtResultado;
        private System.Windows.Forms.Label LblHistorico;
        private System.Windows.Forms.TextBox TxtNumeros;
        private System.Windows.Forms.LinkLabel Historico;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
    }
}

